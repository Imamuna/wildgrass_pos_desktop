﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using WildGrass_Desktop_f8.Activities;
using WildGrass_Desktop_f8.Activities.starter;

namespace WildGrass_Desktop_f8
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            SplashWindow splashWindow = new SplashWindow();
            splashWindow.Show();
            //StarterWindow starterWindow = new StarterWindow();
            //starterWindow.Show();
            //MainWindow main = new MainWindow();
            //main.Show();
        }

    }
}
